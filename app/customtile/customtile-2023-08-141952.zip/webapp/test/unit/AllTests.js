sap.ui.define([
	"customtile/test/unit/controller/MainView.controller"
], function () {
	"use strict";
});
