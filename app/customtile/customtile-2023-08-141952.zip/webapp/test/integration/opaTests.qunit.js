/* global QUnit */

sap.ui.require(["customtile/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
